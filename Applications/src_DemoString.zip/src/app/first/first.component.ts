import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-first',
  templateUrl: './first.component.html'
})

export class FirstComponent
{
  // CHaracteristics
  name : String = "Shreyas Kulkarni";

  // Behaviour
  Display(): string
  {
    var Ret: string = "Hello" + this.name;
    return Ret;
  }

  Addition(no1 : number, no2 : number) : number
  {
    return no1 + no2;
  }
  
  
}


