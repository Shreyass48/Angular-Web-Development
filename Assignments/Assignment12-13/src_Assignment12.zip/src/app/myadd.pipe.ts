import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'myadd'
})
export class MyaddPipe implements PipeTransform {

  transform(value: number, param : number): number
  {
     var no1 = value;
     var no2 = param;
     return no1 + no2;
  }

}
