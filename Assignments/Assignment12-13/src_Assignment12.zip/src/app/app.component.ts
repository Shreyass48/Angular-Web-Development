import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent {
  title = 'Assignment12';

  Name : String = "Marvellous";
  No : number = 11;
}
