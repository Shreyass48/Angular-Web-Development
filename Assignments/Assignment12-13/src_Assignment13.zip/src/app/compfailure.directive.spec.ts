import { CompfailureDirective } from './compfailure.directive';

describe('CompfailureDirective', () => {
  it('should create an instance', () => {
    const directive = new CompfailureDirective();
    expect(directive).toBeTruthy();
  });
});
