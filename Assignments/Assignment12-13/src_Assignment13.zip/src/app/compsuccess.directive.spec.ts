import { CompsuccessDirective } from './compsuccess.directive';

describe('CompsuccessDirective', () => {
  it('should create an instance', () => {
    const directive = new CompsuccessDirective();
    expect(directive).toBeTruthy();
  });
});
