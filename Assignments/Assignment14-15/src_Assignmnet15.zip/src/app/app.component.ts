import { Component, NgModule } from '@angular/core';

// import classes which are required for reactive forms
import {FormBuilder,FormGroup,Validators, FormControl, MinLengthValidator} from '@angular/forms'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent 
{
  constructor(public fobj : FormBuilder)
  { }

  ShreyasForms = this.fobj.group(
    {
      name : ['',[Validators.required, Validators.pattern('^[a-zA-Z ]*$')]],
      Lname : ['',Validators.pattern('^[a-zA-Z ]*$')],
      email : ['',[Validators.required,Validators.email]],
      phone : ['',[Validators.required, Validators.pattern('[0-9]{10}')]],
      city : ['',[Validators.required, Validators.minLength(4), Validators.pattern('^[a-zA-Z ]*$')]],
      zip : ['',Validators.pattern('[0-9]{5}')],
      comments : ['',Validators.minLength(30)]
    } 
  )
}
