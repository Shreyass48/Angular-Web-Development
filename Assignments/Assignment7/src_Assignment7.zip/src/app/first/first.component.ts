import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-first',
  templateUrl: './first.component.html',
  styleUrls: ['./first.component.css']
})
export class FirstComponent {

  // Q2
  // public str = "";

  // public fun()
  // {
  //   this.str = "Marvellous Infosystem";
  //   return this.str;
  // }

  // Q3
  // public str = "Marvellous Infosystems";
  // public fun()
  // {
  //   this.str = "Educating for better tommorow.";
  // }

  public str = "";
  public str2 = "";
  
  public up()
  {
    this.str ="MARVELLOUS INFOSYSTEM";
  }

  public down()
  {
    this.str2 = this.str.toLowerCase();
  }

}
