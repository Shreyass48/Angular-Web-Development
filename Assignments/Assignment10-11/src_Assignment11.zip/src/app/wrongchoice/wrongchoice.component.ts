import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wrongchoice',
  templateUrl: './wrongchoice.component.html',
  styleUrls: ['./wrongchoice.component.css']
})
export class WrongchoiceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
