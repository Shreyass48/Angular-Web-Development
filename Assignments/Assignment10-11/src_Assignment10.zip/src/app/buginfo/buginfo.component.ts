import { Component, OnInit } from '@angular/core';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

@Component({
  selector: 'app-buginfo',
  templateUrl: './buginfo.component.html',
  styleUrls: ['./buginfo.component.css']
})
export class BuginfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
