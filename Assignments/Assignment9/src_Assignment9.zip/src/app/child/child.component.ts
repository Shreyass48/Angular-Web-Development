import { Component, OnInit } from '@angular/core';
import { NumberService } from '../number.service';
import { StringService } from '../string.service';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html'
})
export class ChildComponent implements OnInit {

  constructor(private _obj1 : NumberService, private _obj2 : StringService) 
  { }

  public fret : any;
  public ret : any;

  ngOnInit(): void 
  {
    this.fret = this._obj1.ChkPrime(22); 
    this.ret = this._obj2.countCap("SHreEyas"); 
  }

}
