import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ArithmeticService 
{
  constructor() { }

  public Addition(no1 : number, no2 : number)
  {
    var ans : number = 0;
    ans = no1 + no2;
    return ans;
  }

  public Substraction(no1 : number, no2 : number)
  {
    var ans : number = 0;
    ans = no1 - no2;
    return ans;
  }
}
