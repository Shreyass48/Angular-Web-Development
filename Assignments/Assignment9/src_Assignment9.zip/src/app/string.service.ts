import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StringService {

  public countCap(str : String)
  {
    var str2 = str.toLowerCase();

    var i : number = 0;
    var counter : number = 0;
    for(i = 0; i < str.length;i++)
    {
      if(str[i] != str2[i])
      {
        counter++;
      }
    }

    return counter;
  }

  constructor() { }
}
