import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NumberService 
{

  public ChkPrime(no : number) 
  {
    var flag : boolean = true;
    var i : number = 0;

    for(i = 2; i < no/2; i++)
    {
      if(no % i == 0)
      {
        flag = false;
        break;
      }
    }

    return flag;
  }

  constructor() { }
}
