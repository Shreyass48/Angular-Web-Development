import { Component, OnInit } from '@angular/core';
import { ArithmeticService } from '../arithmetic.service';

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html'
})
export class DemoComponent implements OnInit {

  constructor(private _obj : ArithmeticService) 
  { }

  ans : number = 0;
  ans1 : number = 0;

  ngOnInit(): void 
  {
    this.ans = this._obj.Addition(11,21);
    this.ans1 = this._obj.Substraction(11,21);
  }

}
