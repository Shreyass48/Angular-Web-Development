import { Component, OnInit } from '@angular/core';
import { NumberService } from '../number.service';

@Component({
  selector: 'app-child1',
  templateUrl: './child1.component.html'
})
export class Child1Component implements OnInit 
{


  constructor(private _obj : NumberService) 
  { }

  public fret : any;

  ngOnInit(): void 
  {
    this.fret = this._obj.ChkPrime(22);
  }

}
